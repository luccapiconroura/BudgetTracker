package application;
	
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class BudgetTrackerApp extends Application {

    private BudgetTracker tracker = new BudgetTracker();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);

        // make labels and input for expenses
        Label expenseLabel = new Label("Expense:");
        GridPane.setConstraints(expenseLabel, 0, 0);
        
        TextField expenseInput = new TextField();
        expenseInput.setPromptText("Description");
        GridPane.setConstraints(expenseInput, 1, 0);
        TextField expenseAmount = new TextField();
        expenseAmount.setPromptText("Amount");
        GridPane.setConstraints(expenseAmount, 2, 0);
        Button addExpense = new Button("Add Expense");
        GridPane.setConstraints(addExpense, 3, 0);
        
        Label isRecurringExpense = new Label("Is this a recurring expense?");
        GridPane.setConstraints(isRecurringExpense, 4, 0);
        Button recurringCheck = new Button("Yes");
        GridPane.setConstraints(recurringCheck, 5, 0);
        

        // make labels and input for income
        Label incomeLabel = new Label("Income:");
        GridPane.setConstraints(incomeLabel, 0, 1);
        TextField incomeInput = new TextField();
        incomeInput.setPromptText("Source");
        GridPane.setConstraints(incomeInput, 1, 1);
        TextField incomeAmount = new TextField();
        incomeAmount.setPromptText("Amount");
        GridPane.setConstraints(incomeAmount, 2, 1);
        Button addIncome = new Button("Add Income");
        GridPane.setConstraints(addIncome, 3, 1);

        // show the net amount
        Button computeNet = new Button("Compute Net Amount");
        GridPane.setConstraints(computeNet, 1, 2);
        Label netAmountLabel = new Label("Net Amount: $0.00");
        GridPane.setConstraints(netAmountLabel, 2, 2);

        addExpense.setOnAction(e -> {
            String description = expenseInput.getText();
            double amount = Double.parseDouble(expenseAmount.getText());
            tracker.addExpense(new Expense(description, amount));
            expenseInput.clear();
            expenseAmount.clear();
        });
        
       

        addIncome.setOnAction(e -> {
            String source = incomeInput.getText();
            double amount = Double.parseDouble(incomeAmount.getText());
            tracker.addIncome(new Income(source, amount));
            incomeInput.clear();
            incomeAmount.clear();
        });

        computeNet.setOnAction(e -> {
            netAmountLabel.setText("Net Amount: $" + tracker.getNetAmount());
        });

        grid.getChildren().addAll(expenseLabel, expenseInput, expenseAmount, addExpense, isRecurringExpense, 
        		recurringCheck, incomeLabel, incomeInput, incomeAmount, addIncome, computeNet, netAmountLabel);

        Scene scene = new Scene(grid, 500, 200);
        primaryStage.setTitle("Budget Tracker");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}

